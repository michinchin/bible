function okToHighlight(charBegin, charEnd, node) {
    if (node.nodeName == "#text") {
        return true;
    } else if (hasCSSClass(node, "marginnote", "copyright", "footno", "c", "vno", "cno"))
		return false;
   else if (node.childNodes.length == 1 && hasCSSClass(node, "v"))
		return false;
	else if (parseInt(charBegin) == 0 && parseInt(charEnd) == 9999 && (node.nodeName.substring(0,1).toLowerCase() == "h" || hasCSSClass(node, "suba", "subb", "subhw", "parref", "chapnps", "psnote")))
		return false;
	else
		return true;
}
