function addRules(sheet, rules) {
	for (selector in rules) {
  		if (sheet.insertRule) {
     		try { 
         	sheet.insertRule(selector + rules[selector], sheet.cssRules.length); 
      	} catch(e) {}
   	} else {
      	try { 
         	sheet.addRule(selector, rules[selector]); 
      	} catch(e) {}
   	}               
	}
}

function pageLoaded() {
	var phone, tablet, portrait, landscape, width, height;

	if (screen.height == window.innerWidth) {
		portrait = false;
		width = screen.height;
		height = screen.width;
	}
	else {
		portrait = true;
		width = screen.width;
		height = screen.height;
	}
	
	landscape = !portrait;
	phone = (width <= 600);
	tablet = !phone && (width <= 1024);

	var ns = document.createElement('style');
	document.getElementsByTagName('head')[0].appendChild(ns);

	// some browsers need to have something appended to see the new sheet
	if (!window.createPopup) {
   	  ns.appendChild(document.createTextNode(''));
	}

	var sheet = document.styleSheets[document.styleSheets.length - 1];
    var cnos = document.getElementsByClassName('cno');
    if (cnos.length == 1) {
        var span = cnos[0].querySelector('span[v="0"]');
        if (span) {
           switch(span.textContent.length) {
            case 1:
                var rules = { ".cno" : "{ width: 3em; }" }
		        addRules(sheet, rules);
                break;

            case 2:
                var rules = { ".cno" : "{ width: 6em; }" } 
		        addRules(sheet, rules);
                break;

            case 3:
                var rules = { ".cno" : "{ width: 9em; }" }
		        addRules(sheet, rules);
                break;
            }
        }
    }

	if (phone || tablet) {
		var rules = {
			".para, .indent-text" : "{ text-align: justify; }"
		}

		addRules(sheet, rules);
	}

	if (phone && portrait) {
		var rules = {
			".hang" : "{ margin-left: 1em !important; }",
			".poetry" : "{ padding-left: .75em !important; }",
			".voice-title" : "{ margin-left: 0em !important; margin-right: 0em !important; }",
			".callout" : "{ padding-left: 0em !important; padding-right: 0em !important; }",
			".callout-letter" : "{ margin-right: 0em !important; }"
		}

		addRules(sheet, rules);
	}
}

window.addEventListener("load", pageLoaded, false);
